from kivy.uix.label import Label


#Variables passed into pos_hint() for easy repositioning of labels as one unit.
left = 0.81; center = 0.88; right = 0.95

top = 0.12
middle = 0.08
bottom = 0.04

class labels():

        #Main Label "Battery Voltage"
        batt_volt_label=Label(
                        text='Battery Voltages',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':center, 'center_y':top})

        
        #Secondary label:  "Bank 1"
        bank1_volt_label=Label(
                        text='Bank 1',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':left, 'center_y':middle})
        #Bank 1 Secondary Label indicates voltage value and changes value and colors:
        #green, yellow, red via timer_callback() function in GUI_Layout_VerX.py        
        bank1_volt_value=Label(
                        #text=str(data.HealthData.batt.bank1),
                        text='Wait',
                        color = (0, 1, 0, 1),
                        size_hint=(.1, .1),
                        pos_hint={'center_x':left-0.012, 'center_y':bottom})
        


        #Secondary label:  "Bank 2"
        bank2_volt_label=Label(
                        text='Bank 2',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':center, 'center_y':middle})
        #Bank 2 Secondary Label indicates voltage value and changes value and colors:
        #green, yellow, red via timer_callback() function in GUI_Layout_VerX.py
        bank2_volt_value=Label(
                        text='Wait',
                        color = (0, 1, 0, 1),
                        size_hint=(.1, .1),
                        pos_hint={'center_x':center-0.012, 'center_y':bottom})
        


        #Secondary label:  "Bank 3"
        bank3_volt_label=Label(
                        text='Bank 3',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':right, 'center_y':middle})
        #Bank 2 Secondary Label indicates voltage value and changes value and colors:
        #green, yellow, red via timer_callback() function in GUI_Layout_VerX.py
        bank3_volt_value=Label(
                        text='Wait',
                        color = (0, 1, 0, 1),
                        size_hint=(.1, .1),
                        pos_hint={'center_x':right-0.012, 'center_y':bottom})


        
        
        
