from kivy.app import App
#from kivy.core.video import Video
from kivy.uix.widget import Widget
from kivy.uix.video import Video
from kivy.uix.floatlayout import FloatLayout
import logging
from kivy.logger import Logger
Logger.setLevel(logging.DEBUG)



class RootWidget(FloatLayout):
    def __init__(self, **kwargs):
        super(RootWidget, self).__init__(**kwargs)

        boat_video = video_player()
        boat_video
        






class video_player(Widget):
    def __init__(self, **kwargs):
        super(video_player, self).__init__(**kwargs)

        video=str('http://143.88.94.3:8080/stream?topic=/stereo/left/image_raw')
        my_video=Video(
            source=video,
            state='play',
            play=True,
            eos=True)
        self.add_widget(my_video)



class MainApp(App):
    def build(self):
        return RootWidget()

if __name__ == '__main__':
    MainApp().run()

        
