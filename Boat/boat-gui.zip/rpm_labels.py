from kivy.uix.label import Label


left = 0.05
y_pos = 0.2

class labels():

        #Left Motor RPM Label
        rpm_report_label_left = Label(
                        text='RPM:  ',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':left, 'center_y': y_pos})

        rpm_report_left = Label(
                        text=('NoData'),
                        size_hint=(.1, .1),
                        pos_hint={'center_x':left + .07, 'center_y': y_pos})

        
        rpm_report_label_right = Label(
                        text='RPM:  ',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':(1 - left) - .07, 'center_y': y_pos})

        rpm_report_right = Label(
                        text=('NoData'),
                        size_hint=(.1, .1),
                        pos_hint={'center_x':1 - left, 'center_y': y_pos})        
