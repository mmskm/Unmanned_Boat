

class WidgetData:
    left_motor = 1000
    right_motor = 1000
    start_mode = False
    kill_switch = False
    pump_switch = False
    autonomous_mode = False



class HealthData:
    class water:
        left = True
        center = False
        right = True
    class temp:
        left_mc = 39.9
        right_mc = 50
    class batt:
        bank1 = 20.1
        bank2 = 21.2
        bank3 = 22.3
    class gps:
        lat = 123.456
        lon = 987.654

    
