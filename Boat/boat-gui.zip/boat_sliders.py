from kivy.uix.slider import Slider
from kivy.uix.label import Label

class gui_sliders:
        left_slide=Slider(
                value=1000,
                min=1000,
                max=2000,
                step=1,
                orientation='vertical',
                size_hint= (1, .5),
                pos_hint={'center_x':.08, 'center_y':.5})
        
        left_slide_label=Label(text=str(left_slide.value),
                     size_hint=(.1,.1),
                     pos_hint={'center_x':.03, 'center_y':.5})
        
        right_slide=Slider(
                value=1000,
                min=1000,
                max=2000,
                step=1,
                orientation='vertical',
                size_hint= (1, .5),
                pos_hint={'center_x':.92, 'center_y':.5})

        right_slide_label=Label(
                text=str(right_slide.value),
                size_hint=(.1,.1),
                pos_hint={'center_x':.97, 'center_y':.5})
