#Look into Python matplotlib for graphing gps data


from kivy.app import App
from kivy.graphics import Color, Rectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import AsyncImage
from kivy.uix.slider import Slider
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.image import Image
from kivy.uix.video import Video
from kivy.clock import Clock
from kivy.clock import ClockBase
from kivy.uix.image import Image
from kivy.core.video import Video
from kivy.uix.widget import Widget
import logging
from kivy.logger import Logger
Logger.setLevel(logging.DEBUG)

#My created .py Modules
import data
import water_labels
import voltage_labels        
import temp_labels    
import gps_labels
import boat_sliders
import rpm_labels
#import gps_logging

#Communication Client
import BoatControlClient, MessageService
import asyncore, threading, time



##variables
#setup network communication client.
ip_add_wired='127.0.0.1'
ip_add_wifi = '192.168.1.102'
bcClient = BoatControlClient.BoatControlClient(str(ip_add_wired), 13547)    
#Set tolerances for label colors in timer_callback() function
volt_warn_6s = 22.0
volt_bad_6s = 21.0

volt_warn_4s = 14.5
volt_bad_4s = 13.5

temp_warn = 25.0
temp_bad = 30.0




class RootWidget(FloatLayout):
    def __init__(self, **kwargs):
        super(RootWidget, self).__init__(**kwargs)


#        camera=video_player()
#        self.add_widget(camera)

#        video = video_player()
#        self.add_widget(video)

        
        gui=GUI()
        self.add_widget(gui)


        

#Video Widget to play on root in background

#class video_player(Widget):
#    def __init__(self, **kwargs):
#        super(video_player, self).__init__(**kwargs)
#    def build(self):
#        return video_player(source='http://143.88.93.230:8080/stream?topic=/stereo/left/image_rect_color&type=vp8',
#                           state='play')

        
#        video = str('http://143.88.93.230:8080/stream?topic=/stereo/left/image_rect_color')
#        my_video=Video(
#                    source='http://143.88.93.230:8080/stream?topic=/stereo/left/image_rect_color&type=vp8',
#                    state='play')
        
                    
#        build.Video(my_video)


class GUI(FloatLayout):

    def __init__(self,**kwargs):
        super(GUI,self).__init__(**kwargs)
        

###########################################################################
#Slider Widgets

#        boat_video=video_player()
#        self.add_widget(boat_video)

        #Left Slider          
        left_slid=boat_sliders.gui_sliders.left_slide
        #Updates WidgetData.left_motor in data.py on slider value change
        def OnSliderValueChange(instance, value):
            
            bcClient.setMotorSpeed(left_motor=int(value))
            left_slid_label.text=str(value)
            #data.WidgetData.left_motor=str(value)
            #print('left motor:  ', str(data.WidgetData.left_motor))
        #Bind callback on slider value change 
        left_slid.bind(value=OnSliderValueChange)
        self.add_widget(left_slid)
        #Left slider value Label
        left_slid_label=boat_sliders.gui_sliders.left_slide_label
        self.add_widget(left_slid_label)


        
        #Right Slider      
        right_slid=boat_sliders.gui_sliders.right_slide
        #Updates WidgetData.right_motor in data.py on slider value change
        def OnSliderValueChange(instance, value):
            
            bcClient.setMotorSpeed(right_motor=int(value))
            right_slid_label.text=str(value)
            #data.WidgetData.right_motor=str(value)
            #print('right motor:  ', str(data.WidgetData.right_motor))
        #Bind callback on slider value change    
        right_slid.bind(value=OnSliderValueChange)
        self.add_widget(right_slid)
        #Right slider value Label
        right_slid_label=boat_sliders.gui_sliders.right_slide_label
        self.add_widget(right_slid_label)
        
#End Slider Widgets
###########################################################################




###########################################################################
#Button Widgets



        #Start Mode Toggle Button        
        start_mode_btn=ToggleButton(
                text='Start Mode',
                size_hint=(.12,.07),
                pos_hint={'center_x':.2, 'center_y':.95})
        #
        def callback(start_mode_btn, state):
            if start_mode_btn.state == 'normal':
                left_slid.value=1000
                right_slid.value=1000
                print('Start Mode Disabled')
            elif start_mode_btn.state == 'down':
                left_slid.value=2000
                right_slid.value=2000
                print('Start Mode Enabled')
           
        #Bind callback to state change            
        start_mode_btn.bind(state=callback)
        self.add_widget(start_mode_btn)




        #Kill Switch Toggle Button
        kill_switch_btn=ToggleButton(
                text='Disabled',
                size_hint=(.12,.07),
                state='down',
                pos_hint={'center_x':.4, 'center_y':.95})     
        #Updates BoatControlClient.setRelayStatus(motor_relay=XXXX) value
        def callback(kill_switch_btn, state):
            if kill_switch_btn.state == 'normal':                
                kill_switch_btn.text='Engaged'
                bcClient.setRelayStatus(motor_relay=True)
                print('Motors Engaged')
            elif kill_switch_btn.state == 'down':
                left_slid.value=1000
                right_slid.value=1000
                kill_switch_btn.text='Disabled'
                bcClient.setRelayStatus(motor_relay=False)
                print('Motors Disengaged')
                if start_mode_btn.state=='down':
                    start_mode_btn.state='normal'
                data.WidgetData.kill_switch = True
            
        #Bind callback to state change             
        kill_switch_btn.bind(state=callback)
        self.add_widget(kill_switch_btn)



        
        #Pump Switch Button
        pump_btn=ToggleButton(
                text='Pumps',
                size_hint=(.12,.07),
                pos_hint={'center_x':.6, 'center_y':.95})      
        #Updates WidgetData.pump_switch variable in data.py on state change
        def callback(pump_btn, state):
            if pump_btn.state == 'normal':                
                bcClient.setRelayStatus(pump_relay=False)
            elif pump_btn.state == 'down':
                bcClient.setRelayStatus(pump_relay=True)
            print('Pump Switch:  ', str(data.WidgetData.pump_switch))
        #Bind callback to state change 
        pump_btn.bind(state=callback)
        self.add_widget(pump_btn)



        
        #Autonomous Handoff Button
        auto_btn=ToggleButton(
                text='Autonomous',
                size_hint=(.12,.07),
                pos_hint={'center_x':.8, 'center_y':.95})    
        #Updates WidgetData.autonomous_mode variable in data.py on state change
        def callback(auto_btn, state):
            if auto_btn.state == 'normal':
                print('Autonomous Mode:  normal')
                bcClient.setAutonomousMode(mode = 'manual')
                left_slid.disabled=False
                right_slid.disabled=False
            elif auto_btn.state == 'down':
                print('Autonomous Mode:  auto')
                bcClient.setAutonomousMode(mode = 'autonomous')
                left_slid.disabled=True
                right_slid.disabled=True
        #Bind callback to state change 
        auto_btn.bind(state=callback)
        self.add_widget(auto_btn)

#End Button Widgets
###########################################################################



###########################################################################
#Health Display Widgets


      



#Water Detection Labels
                
        water_sensor_label_top=water_labels.labels.water_sensor_label
        self.add_widget(water_sensor_label_top)

        
        water_left_label=water_labels.labels.water_left_label
        self.add_widget(water_left_label)

        
        water_center_label=water_labels.labels.water_center_label
        self.add_widget(water_center_label)

        water_right_label=water_labels.labels.water_right_label
        self.add_widget(water_right_label)

        water_det_l=water_labels.labels.water_det_left
        self.add_widget(water_det_l)

        water_det_c=water_labels.labels.water_det_center
        self.add_widget(water_det_c)

        water_det_r=water_labels.labels.water_det_right
        self.add_widget(water_det_r)
        




#Create instances of Voltage Monitoring Labels from voltage_labels.py
#Can change label text either through voltage_labels.py, or from this program
#'GUI_Layout_VerX.py' by setting voltage_labels.labels.%label name%.text='new text'
#after label instance is created.  
        #Voltage Top Label "Battery Voltages"
        batt_volt_label_top=voltage_labels.labels.batt_volt_label
        self.add_widget(batt_volt_label_top)
        
        #Voltage Secondary Label "Bank 1"
        bank1_label=voltage_labels.labels.bank1_volt_label
        self.add_widget(bank1_label)
        #Voltage Secondary label "Bank 2"
        bank2_label=voltage_labels.labels.bank2_volt_label
        self.add_widget(bank2_label)
        #Voltage Secondary label "Bank 3"
        bank3_label=voltage_labels.labels.bank3_volt_label
        self.add_widget(bank3_label)

        
        #Voltage Values labels for banks 1, 2, and 3.  Loads default values from
        #data.py, then values switch to values from BoatControlClient.py 
        bank1_value=voltage_labels.labels.bank1_volt_value
        self.add_widget(bank1_value)
        
        bank2_value=voltage_labels.labels.bank2_volt_value
        self.add_widget(bank2_value)

        bank3_value=voltage_labels.labels.bank3_volt_value
        self.add_widget(bank3_value)
        
 
        

        
#Temperature Labels

        temp_sens_label_top=temp_labels.labels.temp_sensors_label
        self.add_widget(temp_sens_label_top)

        temp_sens_left_label=temp_labels.labels.temp_left_mc_label
        self.add_widget(temp_sens_left_label)

        temp_sens_value_l=temp_labels.labels.temp_left_mc_value
        self.add_widget(temp_sens_value_l)

        temp_sens_right_label=temp_labels.labels.temp_right_mc_label
        self.add_widget(temp_sens_right_label)

        temp_sens_value_r=temp_labels.labels.temp_right_mc_value
        self.add_widget(temp_sens_value_r)





#Positioning Data Labels

        gps_label_top=gps_labels.gps_coords.gps_labels
        self.add_widget(gps_label_top)

        gps_label_lat=gps_labels.gps_coords.gps_lat_label
        self.add_widget(gps_label_lat)

        gps_lat=gps_labels.gps_coords.gps_lat_pos
        self.add_widget(gps_lat)

        gps_label_lon=gps_labels.gps_coords.gps_lon_label
        self.add_widget(gps_label_lon)

        gps_lon=gps_labels.gps_coords.gps_lon_pos
        self.add_widget(gps_lon)

        speed_label=gps_labels.gps_orient.gps_speed_label
        self.add_widget(speed_label)

        speed_value=gps_labels.gps_orient.gps_speed_value
        self.add_widget(speed_value)

        head_label=gps_labels.gps_orient.gps_head_label
        self.add_widget(head_label)

        head_value=gps_labels.gps_orient.gps_head_value
        self.add_widget(head_value)
        
        speed_mph=gps_labels.gps_orient.gps_speed_mph
        self.add_widget(speed_mph)

## New labels created

        rpm_left_label=rpm_labels.labels.rpm_report_label_left
        self.add_widget(rpm_left_label)

        rpm_left=rpm_labels.labels.rpm_report_left
        self.add_widget(rpm_left)

        rpm_right_label=rpm_labels.labels.rpm_report_label_right
        self.add_widget(rpm_right_label)

        rpm_right=rpm_labels.labels.rpm_report_right
        self.add_widget(rpm_right)

        next_pt_label_top=gps_labels.next_waypoint.next_point_label_top
        self.add_widget(next_pt_label_top)

        next_pt_lat_label=gps_labels.next_waypoint.next_point_lat_label
        self.add_widget(next_pt_lat_label)

        next_pt_lat_pos=gps_labels.next_waypoint.next_point_lat_pos
        self.add_widget(next_pt_lat_pos)

        next_pt_lon_label=gps_labels.next_waypoint.next_point_lon_label
        self.add_widget(next_pt_lon_label)

        next_pt_lon_pos=gps_labels.next_waypoint.next_point_lon_pos
        self.add_widget(next_pt_lon_pos)        
        
        
#        gps_logging.gps_data()

        def timer_callback(dt):
            
            
            water_left=bcClient.health['water_l']
            water_center=bcClient.health['water_m']
            water_right=bcClient.health['water_r']
            mc_temp_left=bcClient.health['temp_l']
            mc_temp_right=bcClient.health['temp_r']
            batt_volt_pri=bcClient.health['batt_p']
            batt_volt_left=bcClient.health['batt_l']
            batt_volt_right=bcClient.health['batt_r']
            gps_lat_dat=bcClient.location['latitude']
            gps_lon_dat=bcClient.location['longitude']
            gps_fix=bcClient.location['fix']
            speed=bcClient.location['speed']
            heading=bcClient.location['heading']
            rpm_l_value=bcClient.speeds['rpm_l']
            rpm_r_value=bcClient.speeds['rpm_r']
            next_pt=bcClient.status['next_point']
            next_pt_lat=next_pt['lat']
            next_pt_lon=next_pt['lon']
            print next_pt_lat
            print next_pt_lon
            
            speed_conv_mph=speed*1.15078            
            #gps_lat.text=str(gps_lon_dat)
            #gps_lon.text=str(gps_lat_dat)
            #speed_value.text=str(speed)
            #head_value.text=str(heading)

            rpm_left.text=str(rpm_l_value)
            rpm_right.text=str(rpm_r_value)
            next_pt_lat_pos.text=str(next_pt_lat)
            next_pt_lon_pos.text=str(next_pt_lon)
            
#            if right_slid.disabled==True and right_slid.value<2000:
#                right_slid.value=right_slid.value+50
#                left_slid.value=left_slid.value+50
            
            if gps_fix==True:
                gps_lat.text=str(gps_lon_dat)
                gps_lat.color=[0, 1, 0, 1]
                gps_lon.text=str(gps_lat_dat)
                gps_lon.color=[0, 1, 0, 1]
                speed_value.text=str("{:10.2f} knts".format(speed))
                head_value.text=str(heading)
                speed_mph.text=str("{:10.2f} mph".format(speed_conv_mph))
                
            elif gps_fix==False:
                gps_lat.text=str(gps_lon_dat)
                gps_lat.color=[1, 0, 0, 1]
                gps_lon.text=str(gps_lat_dat)
                gps_lon.color=[1, 0, 0, 1]
#                print(gps_lon_dat)
#                print(gps_lat_dat)
                speed_value.text='NoData'
                speed_value.color=[1, 0, 0, 1]
                head_value.text='NoData'
                head_value.color=[1, 0, 0, 1]
                speed_mph.text='NoData'
                speed_mph.color=[1, 0, 0, 1]
            
            if water_left==False:
                water_det_l.text='Good'
                water_det_l.color=[0, 1, 0, 1]   
            elif water_left == True:
                water_det_l.text='Water!'
                water_det_l.color=[1, 0, 0, 1]

            if water_center==False:
                water_det_c.text='Good'
                water_det_c.color=[0, 1, 0, 1]
            elif water_center==True:
                water_det_c.text='Water!'
                water_det_c.color=[1, 0, 0, 1]

            if water_right==False:
                water_det_r.text='Good'
                water_det_r.color=[0, 1, 0, 1]
            elif water_right==True:
                water_det_r.text='Water!'
                water_det_r.color=[1, 0, 0, 1]


                

            if mc_temp_left < temp_warn:
                temp_sens_value_l.text="{:10.2f} C".format(mc_temp_left)
                temp_sens_value_l.color=[0, 1, 0, 1]
            elif temp_warn <= mc_temp_left < temp_bad:
                temp_sens_value_l.text="{:10.2f} C".format(mc_temp_left)
                temp_sens_value_l.color=[1, 1, 0, 1]
            elif temp_bad <= mc_temp_left:
                temp_sens_value_l.text="{:10.2f} C".format(mc_temp_left)
                temp_sens_value_l.color=[1, 0, 0, 1]

            if mc_temp_right < temp_warn:
                temp_sens_value_r.text="{:10.2f} C".format(mc_temp_right)
                temp_sens_value_r.color=[0, 1, 0, 1]
            elif temp_warn <= mc_temp_right < temp_bad:
                temp_sens_value_r.text="{:10.2f} C".format(mc_temp_right)
                temp_sens_value_r.color=[1, 1, 0, 1]
            elif temp_bad <= mc_temp_right:
                temp_sens_value_r.text="{:10.2f} C".format(mc_temp_right)
                temp_sens_value_r.color=[1, 0, 0, 1]




            if batt_volt_left > volt_warn_6s:
                bank1_value.text="{:10.2f}".format(batt_volt_left)
                bank1_value.color=[0, 1, 0, 1]
            elif volt_warn_6s >= batt_volt_left > volt_bad_6s:
                bank1_value.text="{:10.2f}".format(batt_volt_left)
                bank1_value.color=[1, 1, 0, 1]
            elif volt_bad_6s >= batt_volt_left:
                bank1_value.text="{:10.2f}".format(batt_volt_left)
                bank1_value.color=[1, 0, 0, 1]




            if batt_volt_pri > volt_warn_4s:
                bank2_value.text="{:10.2f}".format(batt_volt_pri)
                bank2_value.color=[0, 1, 0, 1]
            elif volt_warn_4s >= batt_volt_pri > volt_bad_4s:
                bank2_value.text="{:10.2f}".format(batt_volt_pri)
                bank2_value.color=[1, 1, 0, 1]
            elif volt_bad_4s >= batt_volt_pri:
                bank2_value.text="{:10.2f}".format(batt_volt_pri)
                bank2_value.color=[1, 0, 0, 1]


            if batt_volt_right > volt_warn_6s:
                bank3_value.text="{:10.2f}".format(batt_volt_right)
                bank3_value.color=[0, 1, 0, 1]
            elif volt_warn_6s >= batt_volt_right > volt_bad_6s:
                bank3_value.text="{:10.2f}".format(batt_volt_right)
                bank3_value.color=[1, 1, 0, 1]
            elif volt_bad_6s >= batt_volt_right:
                bank3_value.text="{:10.2f}".format(batt_volt_right)
                bank3_value.color=[1, 0, 0, 1]


            

            print('In callback')
            
        Clock.schedule_interval(timer_callback, 0.1)



#End Health Display Widgets
###########################################################################





                


   
class MainApp(App):
    def build(self):
        self.title = 'Boat Controller [UWF Boat Team]'
        return RootWidget()

if __name__ == '__main__':
    MainApp().run()
