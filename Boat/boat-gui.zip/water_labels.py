from kivy.uix.label import Label


left = 0.05; center = 0.12; right = 0.19

top = 0.12
middle = 0.08
bottom = 0.04

class labels():

        #Main Label: "Water Sensors"
        water_sensor_label=Label(
                        text='Water Sensors',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':center, 'center_y':top})
        


        #Secondary Label: "Left"        
        water_left_label=Label(
                        text='Left',
                        size_hint=(.1,.1),
                        pos_hint={'center_x':left, 'center_y':middle})
        

        
        #Left Secondary Indicator Label text and color changes in GUI_Layout_VerX.py
        #during timer_callback() function. 
        water_det_left=Label(
                        text='Wait',
                        color = (0, 1, 0, 1),
                        size_hint=(.1,.1),
                        pos_hint={'center_x':left, 'center_y':bottom})
        

 




        #Secondary Label: "Center"         
        water_center_label=Label(
                        text='Center',
                        size_hint=(.1,.1),
                        pos_hint={'center_x':center, 'center_y':middle})
        


        #Center Secondary Indicator Label text and color changes in GUI_Layout_VerX.py
        #during timer_callback() function.                            
        water_det_center=Label(
                        text='Wait',
                        color = (0, 1, 0, 1),
                        size_hint=(.1,.1),
                        pos_hint={'center_x':center, 'center_y':bottom})
        





    
        #Secondary Label: "Right"
        water_right_label=Label(
                        text='Right',
                        size_hint=(.1,.1),
                        pos_hint={'center_x':right, 'center_y':middle})
        

        #Right Secondary Indicator Label text and color changes in GUI_Layout_VerX.py
        #during timer_callback() function.                       
        water_det_right=Label(
                        text='Wait',
                        color = (0, 1, 0, 1),
                        size_hint=(.1,.1),
                        pos_hint={'center_x':right, 'center_y':bottom})
        
       
#        water_det_right_true=Label(
#                        text='WATER!',
#                        color = (1, 0, 0, 1),
#                        size_hint=(.1,.1),
#                        pos_hint={'center_x':right, 'center_y':bottom})
        
