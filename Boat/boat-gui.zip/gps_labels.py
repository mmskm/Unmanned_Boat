from kivy.uix.label import Label



left = 0.35; center = 0.5; right = 0.55

top = 0.90
middle = 0.87
bottom = 0.79

class gps_coords():

    gps_labels=Label(
                    text='GPS Coordinates',
                    size_hint=(.1, .1),
                    pos_hint={'center_x':center, 'center_y':top})
    
    gps_lat_label=Label(
                    text='Latitude:',
                    size_hint=(.1, .1),
                    pos_hint={'center_x':left, 'center_y':middle})

    gps_lat_pos=Label(
                    text='Wait',
 #                   color=(1, 0, 0, 1),
                    size_hint=(.1, .1),
                    pos_hint={'center_x':left+0.1, 'center_y':middle})
    

    gps_lon_label=Label(
                    text='Longitude:',
                    size_hint=(.1, .1),
                    pos_hint={'center_x':right, 'center_y':middle})

    gps_lon_pos=Label(
                    text='Wait',
#                   color=(1, 0, 0, 1),
                    size_hint=(.1, .1),
                    pos_hint={'center_x':right+0.1, 'center_y': middle})


#    gps_no_fix=Label(
#		    text='No GPS Fix', 
#		    size_hint=(.15, .15),
#		    color=(1, 0, 0, 1),
#		    pos_hint={'center_x':center, 'center_y':.70})


class next_waypoint():
    next_point_label_top=Label(
		    text='Next Waypoint',
		    size_hint=(.1, .1),
		    pos_hint={'center_x':center, 'center_y':top-.07})
    
    next_point_lat_label=Label(
                    text='Latitude:',
                    size_hint=(.1, .1),
                    pos_hint={'center_x':left, 'center_y':middle-.07})
    
    next_point_lat_pos=Label(
                    text='Wait',
 #                   color=(1, 0, 0, 1),
                    size_hint=(.1, .1),
                    pos_hint={'center_x':left+0.1, 'center_y':middle-.07})

    next_point_lon_label=Label(
                    text='Longitude:',
                    size_hint=(.1, .1),
                    pos_hint={'center_x':right, 'center_y':middle-.07})
    
    next_point_lon_pos=Label(
                    text='Wait',
#                   color=(1, 0, 0, 1),
                    size_hint=(.1, .1),
                    pos_hint={'center_x':right+0.1, 'center_y': middle-.07})




class gps_orient():
    gps_speed_label=Label(
		    text='Speed',
		    size_hint=(.1, .1),
		    pos_hint={'center_x':.07, 'center_y':.95})
    
    gps_speed_value=Label(
		    text='Wait',
		    size_hint=(.1, .1),
		    pos_hint={'center_x':.06, 'center_y':.90})
     
    gps_speed_mph=Label(
                    text='Wait',
                    size_hint=(.1, .1),
                    pos_hint={'center_x':.06, 'center_y':.85})
    
    gps_head_label=Label(
		    text='Heading',
		    size_hint=(.1, .1),
		    pos_hint={'center_x':.93, 'center_y':.95})
    
    gps_head_value=Label(
		    text='Wait', 
		    size_hint=(.1, .1),
		    pos_hint={'center_x':.93, 'center_y':.90})



  
    
