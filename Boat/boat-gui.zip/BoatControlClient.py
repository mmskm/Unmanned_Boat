#!/usr/bin/env python


import MessageService
import threading, asyncore, json

import time

class BoatControlClient:
    '''Client class for boat control.  Takes messages from service and readies
    them for the GUI,and passes commands from the GUI to the boat.
    '''
    location = {'fix':         False,
                'latitude':    0.0,
                'longitude':   0.0,
                'speed':       0.0,
                'heading':     0.0}
    health =   {'temp_l':      0.0,
                'temp_r':      0.0,
                'temp_pc':     None,
                'batt_p':      0.0,
                'batt_r':      0.0,
                'batt_l':      0.0,
                'water_l':     False,
                'water_r':     False,
                'water_m':     False}
    relays =   {'pump':        False,
                'motor':       False}
    motors =   {'left_motor':  1000,
                'right_motor': 1000}
    speeds =   {'rpm_l':       0,
                'rpm_r':       0}
    status =   {'mode':        'manual',
                'challenge':   'testing',
                'next_point':  {'lat': 0.00, 'lon': 0.00}}

    def __init__(self, addr, port):
        # Start the message client and connect to the message server
        self.msgClient = MessageService.MessageClient(addr, port, self.recvMsg)
        self.asyncThread = threading.Thread(target=asyncore.loop,
                                            name="Asyncore Loop")
        self.asyncThread.daemon = True
        self.asyncThread.start()
        
    def __del__(self):
        self.msgClient.close()
        
    def recvMsg(self, msg):
        try:
            # Decode JSON formatted data, then call functions based on the data
            # received
            received_data = json.loads(msg)
            self.health = received_data['health']
            self.location = received_data['location']
            self.speeds = received_data['motor_speeds']
            self.status = received_data['status']
        except (ValueError, KeyError):
            print msg

    def sendMsg(self):
        msg = {'relays': self.relays,
               'motors': self.motors,
               'status': self.status}
        self.msgClient.send_message(json.dumps(msg) + '\n')

    def setMotorSpeed(self,left_motor=-1,right_motor=-1):
        if left_motor != -1:
            self.motors['left_motor'] = left_motor
        if right_motor != -1:
            self.motors['right_motor'] = right_motor
        self.sendMsg()
    
    def setRelayStatus(self,pump_relay=-1,motor_relay=-1):
        if motor_relay != -1:
            self.relays['motor'] = motor_relay
        if pump_relay != -1:
            self.relays['pump'] = pump_relay
        self.sendMsg()
    
    def setAutonomousMode(self,mode='manual'):
        self.status['mode'] = mode
        self.sendMsg()

if __name__ == '__main__':
    raise RuntimeError('This is an included class, not to be run directly!')
