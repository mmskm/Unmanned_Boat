from kivy.uix.label import Label


#Alignment/Positioning Variables passed into labels to make
#repositioning easy. 
left = 0.43; center = 0.5; right = 0.57

top = 0.12
middle = 0.08
bottom = 0.04

class labels():
    #Top Label: "Motor Controller Temps"
    temp_sensors_label=Label(
                        text='Motor Controller Temps',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':center, 'center_y':top})
    
    #Secondary Label Left:  "Left MC Temp"
    temp_left_mc_label=Label(
                        text='Left MC Temp',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':left, 'center_y':middle})
    #Left Motor Controller Temperature Value Label, changes text and color in GUI_Layout_VerX.py
    #during timer_callback() function
    temp_left_mc_value=Label(
                        text='Wait',
                        color=(0, 1, 0, 1),
                        size_hint=(.1, .1),
                        pos_hint={'center_x':left, 'center_y':bottom})
    

    #Secondary Label Right:  "Right MC Temp"
    temp_right_mc_label=Label(
                        text='Right MC Temp',
                        size_hint=(.1, .1),
                        pos_hint={'center_x':right, 'center_y':middle})
    #Left Motor Controller Temperature Value Label, changes text and color in GUI_Layout_VerX.py
    #during timer_callback() function
    temp_right_mc_value=Label(
                        text='Wait',
                        color=(0, 1, 0, 1),
                        size_hint=(.1, .1),
                        pos_hint={'center_x':right, 'center_y':bottom})
    

