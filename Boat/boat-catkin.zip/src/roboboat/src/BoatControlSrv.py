#!/usr/bin/env python

import rospy, json, socket, sys
from roboboat.msg import BoatHealth, MotorControl, RelayControl
from nmea_msgs.msg import Sentence as NMEASentence

import time

class BoatControlSrv:
    """ROS Module, handles communication to control client"""

    def __init__(self, sock=None):
        if sock is None:
            self.sock = socket.socket(
                socket.AF_INET, socket.SOCK_STREAM)
        else:
            sock.sock = sock

        # A Publisher for each topic
        self.motorPub = rospy.Publisher("motor_control", MotorControl, queue_size=2)
        self.relayPub = rospy.Publisher("relay_control", RelayControl, queue_size=2)
        #rospy.init_node('boat_control_srv')

        # A Subscriber for each topic
        self.sub = rospy.Subscriber("health", BoatHealth, self.healthCallback)
        self.sub = rospy.Subscriber("gps_nmea", NMEASentence, self.gpsCallback)


    def connect(self, host, port):
        self.sock.connect((host, port))

    def gpsCallback(self, data):
        rospy.loginfo(rospy.get_name()+ "%s", data.sentence)

    def healthCallback(self,data):
        pass

    def testMotor(self):
        for i in range(1000,2000,10):
            msg = MotorControl()
            msg.left_motor = i
            msg.right_motor = i
            msg.header.stamp = rospy.Time.now()
            self.motorPub.publish(msg)
            time.sleep(.05)
        print "loop 1 done"
        for j in range(2000,1000,-10):
            msg = MotorControl()
            msg.left_motor = j
            msg.right_motor = j
            msg.header.stamp = rospy.Time.now()
            self.motorPub.publish(msg)
            self.motorPub.publish(msg)
            time.sleep(.05)
        print "loop 2 done"



def main(args):
    '''Initialize and clean up ROS node'''
    bc = BoatControlSrv()
    
    rospy.init_node('boat_control_srv')

    bc.testMotor()
    
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print "Shutting down boat control node"

if __name__ == '__main__':
    main(sys.argv)
        
        

