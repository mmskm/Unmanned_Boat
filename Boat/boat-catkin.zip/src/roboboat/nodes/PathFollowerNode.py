#!/usr/bin/env python
# -*- coding: latin-1 -*-


import numpy as np
import math
import time
import rospy
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist, Point
from roboboat.msg import LineSegment



class PathFollower:
    '''Implementation of a path following algorithm loosely based on Pure Pursuit'''
    
    start_point = (None,None)
    end_point = (None,None)
    # Minimum Lookahead Distance, in meters
    look_dist = 0
    # Maximum lookahead distance for adaptive lookahead
    look_max_limit = 1.0
    # Minimum Linear Velocity 
    vel = 0.1
    # Maximum Velocity, in meters per second
    max_vel = 1
    
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('PathFollower')
        
        # Set up Publisher
        self._vel_pub = rospy.Publisher('/roboboat/set_velocity', Twist, queue_size=10)
        
        # Set up Subscribers
        self._pose_sub = rospy.Subscriber('/odometry/filtered', Odometry, self.find_velocities)
        self._path_sub = rospy.Subscriber('/roboboat/path_segment', LineSegment, self.update_path)
        
        rospy.loginfo(rospy.get_name() + ':  Initializing Path Follower Node.')
    
    def _find_segment_angle(self,a,b):
        '''Returns the angle between the global frame and line segment AB'''
        return math.atan2( ((b[1, 0] - a[1, 0])),
                           ((b[0, 0] - a[0, 0]) ))
    
    def _heading_from_quaternion(self,orientation):
       '''Takes a quaternion input, returns heading/yaw'''
       quat = (orientation.x,
               orientation.y,
               orientation.z,
               orientation.w)
       euler = transformations.euler_from_quaternion(quat)
       return euler(2)
     
    def _inv_rot(self,angle):
        '''Returns an inverse rotation matrix'''
        return np.matrix([[ math.cos(angle), math.sin(angle)],
                          [-math.sin(angle), math.cos(angle)]])
    def _ang_vel(self, lookahead_R, vel, look):
        ang_vel =  ( (2 * lookahead_R[1, 0] * vel) / (pow(look,2)))
        return ang_vel
    
    def update_path(self,path_start,path_end):
        '''Updates the current path endpoints'''
        self.start_point = path_start
        self.end_point   = path_end
        
    def find_velocities(self,cur_pos):
        '''Outputs the needed linear and angular velocities'''
        
            # start and end points 
        A = np.matrix([[start_point(0)], [start_point(1)]])
        B = np.matrix([[end_point(0)], [end_point(1)]])
        angle_AB = _find_segment_angle(A, B)
        inv_rot_AB = _inv_rot(angle_AB)
            
        #current bot position and heading passed into find_velocities
        bot_pos = np.matrix([[cur_pos.pose.pose.position.x], [cur_pos.pose.pose.position.y]])            
        bot_heading = self._heading_from_quarternion(cur_pos.pose.pose.orientation)
	    
        translation = np.subtract(bot_pos, A)            
        bot_pos_AB = np.dot(inv_rot_AB, translation)
        bot_heading_AB = (bot_heading - angle_AB)
	    
	    #Adjust lookahead, if lookahead_AB results in complex numbers
        look = look_dist
        while( (pow(bot_pos_AB[1, 0], 2)) > (pow(look, 2)) ):
	  #can fine tune this if execution time is too long, or if 
	  #better resolution is desired for the adaptive lookahead
            look = look + 0.05
            if look >= look_ahead_upper_limit:
                break
	  
        lookahead_AB = np.matrix([[np.add(bot_pos_AB[0, 0], (math.sqrt(pow(look, 2)
                                   - pow(bot_pos_AB[1, 0], 2))))], [0]])
        rot_AB_to_R = inv_rot(bot_heading_AB)
        translation = np.subtract(lookahead_AB, bot_pos_AB)
        lookahead_R = np.dot(rot_AB_to_R, translation)
            
        # calculate the angular velocity using the linear velocity upper limit
        vel = vel_upper_limit
        bot_ang_vel = _ang_vel(lookahead_R, vel, look)            
        # adjusts linear velocity depending on the magnitude of the angular velocity
        while (bot_ang_vel <= (-math.pi/4) or bot_ang_vel >= (math.pi/4)):
            # this can be fine tuned to increase/decrease resolution of adaptive linear velocity
            vel = vel -0.01
            bot_ang_vel = _ang_vel(lookahead_R, vel, look)
      
        vel_msg = Twist()
        vel_msg.linear.x = vel
        vel_msg.angular.z = bot_ang_vel
            
            
                    
	# Publish message
	self._vel_pub.publish(vel_msg)



def start_node():
    # Create path follower
    pf = PathFollower()

    # Spin until program exits
    rospy.spin()


if __name__ == '__main__':
    try:
        start_node()# Publish message
        self._vel_pub.publish(vel_msg)
    except rospy.ROSInterruptException:
        pass