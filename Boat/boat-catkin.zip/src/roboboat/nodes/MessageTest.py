#!/usr/bin/env python

import MessageService
import BoatControlClient
import asyncore, threading, time


def theCB(msg):
    print msg



#addr = ('localhost', 13547)
#srv = MessageService.MessageServer(addr, theCB)

#client = MessageService.MessageClient('localhost', 13547, theCB)

#client = BoatControlClient.BoatControlClient('143.88.93.147', 13547)
client = BoatControlClient.BoatControlClient('localhost', 13547)

#loop_thread = threading.Thread(target=asyncore.loop, name="Asyncore Loop")
# If you want to make the thread a daemon
#loop_thread.daemon = True

#loop_thread.start()

#for i in range(1, 10):
#    client.setRelayStatus(pump_relay=True,motor_relay=True)
#    time.sleep(1)
#    client.setRelayStatus(pump_relay=False,motor_relay=False)
#    time.sleep(1)


client.setMotorSpeed(left_motor=1500,right_motor=1500)
time.sleep(3)
client.setMotorSpeed(left_motor=1000,right_motor=1000)


#client.close()
#srv.close()
