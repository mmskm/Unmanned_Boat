#!/usr/bin/env python


import asyncore, asynchat, socket

class MessageServer(asyncore.dispatcher):

    def __init__(self, addr):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.bind(addr)
        self.addr = self.socket.getsockname()
        self.listen(1)
    
    def handle_accept(self):
        client_info = self.accept()
        MessageHandler(sock=client_info[0])
        
    def handle_close(self):
        self.close()
        


class MessageHandler(asynchat.async_chat):
    
    def __init__(self,sock, ):
        self.in_buffer = []
        self.out_buffer = []
        asynchat.async_chat.__init__(self, sock)
        # Start looking for the ECHO command
        #self.process_data = self._process_command
        self.set_terminator('\n')
        
    def collect_incoming_data(self, data):
        """Read an incoming message from the client and put it into our outgoing queue."""
        self.in_buffer.append(data)

    def found_terminator(self):
        received_message = ''.join(self.in_buffer)
        self.callback(received_message)
        self.in_buffer = []
        
    def send_message(self, msg):
        self.push_with_producer(EchoProducer(msg, buffer_size=self.ac_out_buffer_size))


class EchoProducer(asynchat.simple_producer):
    def more(self):
        response = asynchat.simple_producer.more(self)
        return response