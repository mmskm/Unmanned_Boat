#!/usr/bin/env python

import asyncore
import asynchat
import socket


class MessageClient(asynchat.async_chat):
    """Sends messages to the server and receives responses.
    """
    def __init__(self, host, port, callback):
        self.in_buffer = []
        self.out_buffer = []
        self.message = """Pants!\nWoo!!\n"""
        asynchat.async_chat.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((host, port))
        self.set_terminator("\n")
        return
        
    def handle_connect(self):
        # Send the data
        pass
    
    def collect_incoming_data(self, data):
        """Read an incoming message from the client and put it into our outgoing queue."""
        self.in_buffer.append(data)

    def found_terminator(self):
        received_message = ''.join(self.in_buffer)
        self.callback(received_message)
        self.in_buffer = []
        
    def send_message(self, msg):
        self.push_with_producer(EchoProducer(msg, buffer_size=self.ac_out_buffer_size))


class EchoProducer(asynchat.simple_producer):
    def more(self):
        response = asynchat.simple_producer.more(self)
        return response