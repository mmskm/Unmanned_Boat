#!/usr/bin/env python
# -*- coding: latin-1 -*-

import rospy
import json
import socket
import sys
import time
import asyncore
import threading
import re
import subprocess
from roboboat.msg import BoatHealth, MotorControl, MotorSpeed, RelayControl
from nmea_msgs.msg import Sentence as NMEASentence
from sensor_msgs.msg import Imu as ImuMsg
from MessageService import MessageServer

import logging


class BoatControlSrv:
    '''ROS Module, handles communication to control client'''
    location = {'fix': False,
                'latitude':    0.0,
                'longitude':   0.0,
                'speed':       0.0,
                'heading':     0.0}
    health =   {'temp_l':      0.0,
                'temp_r':      0.0,
                'temp_pc':    None,
                'batt_p':      0.0,
                'batt_r':      0.0,
                'batt_l':      0.0,
                'water_l':     False,
                'water_r':     False,
                'water_m':     False}
    relays =   {'pump':        False,
                'motor':       False}
    motors =   {'left_motor':  1000,
                'right_motor': 1000}
    speeds =   {'rpm_l':       0,
                'rpm_r':       0}
    status =   {'mode':        'manual',
                'challenge':   'testing',
                'next_point':  {'lat': 0.00, 'lon': 0.00}}

    def __init__(self):
        # A Publisher for each topic
        self.motorPub = rospy.Publisher("motor_control",
                                        MotorControl,
                                        queue_size=2)
        self.relayPub = rospy.Publisher("relay_control",
                                        RelayControl,
                                        queue_size=2)

        # A Subscriber for each topic
        self.healthSub = rospy.Subscriber("health",
                                          BoatHealth,
                                          self.healthCallback)
        self.gpsSub = rospy.Subscriber("gps_nmea",
                                       NMEASentence,
                                       self.gpsCallback)
        self.imuSub = rospy.Subscriber("imu/data",
                                       ImuMsg,
                                       self.imuCallback)
        self.rpmSub = rospy.Subscriber("motor_speed",
                                       MotorSpeed,
                                       self.rpmCallback)
        
        # Start the Message Server
        self.msgSrv = MessageServer(('0.0.0.0', 13547), self.recvMsg)
        self.asyncThread = threading.Thread(target=asyncore.loop,
                                            name="Asyncore Loop")
        self.asyncThread.daemon = True
        self.asyncThread.start()
        
    def __del__(self):
        self.msgSrv.close()

#    def connect(self, host, port):
#        self.sock.connect((host, port))
        
    def _decodeNMEA(self, s):
        '''Splits the NMEA sentence and sets variables'''
        utc_time, fix, lat, lat_dir, lon, lon_dir, speed, heading = s.split(',')[1:9]
        try:
            if fix == 'A':
                lat = float(lat)
                lon = float(lon)
            else:
                lat = 0.0
                lon = 0.0
        except ValueError:
            rospy.logerr("%s", s)
            pass

        try:
            speed = float(speed)
            heading = float(heading)
        except ValueError:
            pass
        
        if lat_dir == 'W':
            lat = 0.0 - float(lat)
        
        if lon_dir == 'S':
            lon = 0.0 - float(lat)

        if fix == 'A':
            fix = True
        elif fix == 'V':
            fix = False
        
        self.location = {'fix': fix,
                         'latitude': lat,
                         'longitude': lon,
                         'speed': speed,
                         'heading': heading}
        
    def _verifyNMEAChecksum(self, s):
        '''Calculates the NMEA checksum, and verifies the incoming data is good.
        '''
        try:
            data, cksum = s[1:].strip().rsplit('*',1)
        except:
            return False
        cal_sum = 0
        for s in data:
            cal_sum ^= ord(s)
        
        if '0x'+cksum == hex(cal_sum):
            return True
        else:
            return False

    def gpsCallback(self, data):
        if data.sentence[:7] == '$GPRMC,':
            #print data.sentence
            if self._verifyNMEAChecksum(data.sentence):
                self._decodeNMEA(data.sentence)
                rospy.logdebug(rospy.get_name()
                               + '[GPS]: '
                               + json.dumps(self.location, sort_keys=True))

    def healthCallback(self,data):
        self.health = {'temp_l': data.temp_l,
                       'temp_r': data.temp_r,
                       'temp_pc': None,
                       'batt_p': data.batt_p,
                       'batt_r': data.batt_r,
                       'batt_l': data.batt_l,
                       'water_l': data.water_l,
                       'water_r': data.water_r,
                       'water_m': data.water_m}
        rospy.logdebug(rospy.get_name()
                       + '[Health]: '
                       + json.dumps(self.location, sort_keys=True))

    def imuCallback(self,data):
        pass
    
    def rpmCallback(self,data):
        self.speeds = {'rpm_l': data.rpm_l,
                       'rpm_r': data.rpm_r}
        rospy.logdebug(rospy.get_name() +
                       '[MotorSpeed]: ' +
                       json.dumps(self.speeds, sort_keys=True))

    def getPCTemps(self):
        # CPU Temps
        try:
            sensors = subprocess.check_output(['sensors', 'coretemp-isa-0000'])
            temps = {match[0]: float(match[1]) for match in re.findall(u'^(.*?)\:\s+\+?(.*?)\xc2\xb0C', sensors, re.MULTILINE | re.UNICODE)}
        except subprocess.CalledProcessError:
            pass
        # HDD Temp
        try:
            hddtemp = subprocess.check_output(['hddtemp', '/dev/sda'])
            temps['hdd'] = float(re.search(u'/dev/sda.*\:\s+(.*?)\xc2\xb0C', hddtemp).group(1))
        except:
            pass
        return temps
    
    def sendMsg(self, event):
        '''Send the boat status messages to the client.'''
        
        # Update PC temps
        self.health['temp_pc'] = self.getPCTemps()
        
        # check for socket connection
        if self.msgSrv.handler:
            if self.msgSrv.handler.connected == False:
                rospy.loginfo("Client Disconnected -- Setting motors to 0")
                self.motors =   {'left_motor': 1000,
                                 'right_motor': 1000}
                self.sendROSMsg()
                self.msgSrv.handler = None
                return

            message = {'location': self.location,
                       'health': self.health,
                       'motor_speeds': self.speeds,
                       'status': self.status}
            rospy.logdebug(rospy.get_name()
                           + ': '
                           + json.dumps(message, sort_keys=True))
            rospy.loginfo(rospy.get_name()+ ': Sent Message')
            self.msgSrv.handler.send_message(json.dumps(message, sort_keys=True)
                                             + "\n")

    def recvMsg(self, msg):
        '''Decodes incoming data and calls the functions to update boat
           parameters
        '''
        try:
            # Decode JSON formatted data, then call functions based on the data
            # received
            received_data = json.loads(msg)
            rospy.loginfo(rospy.get_name() + ': Received Message')
            self.relays = received_data['relays']
            self.motors = received_data['motors']
            self.status['mode'] = received_data['status']['mode']
            self.sendROSMsg()
        except (ValueError, KeyError):
            print msg
    
    def sendROSMsg(self):
        '''Send the ROS messages that control the relays and motor speeds.'''
        # Gets the current time for the headers in the ROS messages
        now = rospy.Time.now()
        
        # Set and send relay state message
        rc = RelayControl()
        rc.pump = self.relays['pump']
        rc.motor = self.relays['motor']
        rc.header.stamp = now
        self.relayPub.publish(rc)
        
        if self.status['mode'] == 'manual':
            # Set and send motor speed message
            mc = MotorControl()
            mc.left_motor = self.motors['left_motor']
            mc.right_motor = self.motors['right_motor']
            mc.source_id = mc.SOURCE_MANUAL
            mc.header.stamp = now
            self.motorPub.publish(mc)


if __name__ == '__main__':
    try:
        '''Initialize and clean up ROS node'''
        rospy.init_node('boat_control_srv')
        rospy.loginfo('Initializing boat control service.')
    
        bc = BoatControlSrv()

        # Send the health message to the client at 2 Hz
        rospy.Timer(rospy.Duration(.5), bc.sendMsg)
        rospy.spin()
    except IndexError:
        print "Index Error"
    except KeyboardInterrupt:
        print "Shutting down boat control node"
    except socket.error as e:
        rospy.logerr("Opening socket failed: %s", e)


        

