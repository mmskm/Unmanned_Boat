#!/usr/bin/env python
# -*- coding: latin-1 -*-


import rospy
from geometry_msgs.msg import Twist
from roboboat.msg import MotorControl


class BoatSpeedControl:
    '''Subscribes to /roboboat/set_velocity, calculates the required throttle
       positions, and push them to the boat
    '''
    RPM_MAX = 26000
    RPM_MIN = 0
    SLIP = 0.80
    # Pitch of blade, converted from inch/rev to meters/radian
    PITCH = 0.008934
    # Distance between centers of propellers, in meters
    PROP_SEPARATION = 0.435 * 3
    
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('BoatSpeedControl')
        
        # Set up Publisher
        self._throttle_pub = rospy.Publisher('/motor_control',
                                             MotorControl,
                                             queue_size=10)
        
        # Set up Subscriber
        self._vel_sub = rospy.Subscriber('/roboboat/set_velocity',
                                         Twist,
                                         self.set_throttles)
        
        rospy.loginfo(rospy.get_name()
                      + ':  Initializing BoatSpeedControl Node.')
    
    def _ang_vel_to_ns(self,w):
        ''' Remaps the desired motor speed, in radians per second to the
            throttle setting, in nanoseconds from 1000-2000
        '''
        # Convert from rad/s to RPM
        w = w * 9.5493
        print w
        
        # Divide by RPM_MAX, multiply by 1000ns, add 1000ns
        throttle = (w / self.RPM_MAX) * 1000 + 1000
        
        if throttle > 2000:
            return 2000
        return throttle
    
    def set_throttles(self, twist):
        '''Using the desired angular and linear velocities, this sets
           the throttle speeds of the left and right motors.
        '''
        # Desired Angular and Linear velocity, from ROS msg
        w_boat = twist.angular.z
        v_boat = twist.linear.x
        
        # Calculate the coefficient of the Jacobian kinematic matrix
        kin_coeff = 1 / (self.PITCH * (1-self.SLIP))
        
        # Calculate needed left and right motor angular velocities
        w_left  = kin_coeff * (v_boat - (self.PROP_SEPARATION/2) * w_boat)       
        w_right = kin_coeff * (v_boat + (self.PROP_SEPARATION/2) * w_boat)
        
        rospy.loginfo("Setting motors, w = " + str(w_boat)
                      + " v = " + str(v_boat)
                      + " w_left = " + str(w_left)
                      + " w_right = " + str(w_right))
        
        # Set up and publish throttle message
        throttle_msg = MotorControl()
        throttle_msg.source_id    = throttle_msg.SOURCE_AUTONOMOUS
        throttle_msg.header.stamp = rospy.Time.now()
        throttle_msg.left_motor   = self._ang_vel_to_ns(w_left)
        throttle_msg.right_motor  = self._ang_vel_to_ns(w_right)
        
        self._throttle_pub.publish(throttle_msg)
    
    
    
    
    
if __name__ == '__main__':
    try:
        # Create path generator
        bsc = BoatSpeedControl()

        # Spin until program exits
        rospy.spin()
    except rospy.ROSInterruptException:
        pass