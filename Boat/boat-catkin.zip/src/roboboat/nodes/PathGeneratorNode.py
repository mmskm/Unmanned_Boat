#!/usr/bin/env python
# -*- coding: latin-1 -*-


#import numpy as np
#import math
#import time
import rospy
from nav_msgs.msg import Odometry
#from geometry_msgs.msg import Twist, Point
from roboboat.msg import LineSegment



class PathGenerator:
    '''A path generator, contains waypoints and will update the next waypoint
       in the path based on the current location of the boat.
    '''
    
    path = []
    next_waypoint = 0
    threshold = 0.29
    
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('PathGenerator')
        
        # Set up Publisher
        self._path_pub = rospy.Publisher('/roboboat/path_segment',
                                         LineSegment,
                                         queue_size=10)
        
        # Set up Subscriber
        self._pose_sub = rospy.Subscriber('/odometry/filtered',
                                          Odometry,
                                          self.check_threshold)
        
        rospy.loginfo(rospy.get_name() + ':  Initializing Path Follower Node.')
    
    def _get_distance_to_waypoint(self,loc,wp):
        '''Returns the distance to the next waypoint, in meters'''
        distance = ((loc[0]-wp[0])**2 + (loc[1]-wp[1])**2)**0.5
        return distance
    
    def add_waypoint(self,waypoint):
        '''Adds a waypoint to the end of the list'''
        self.path.append(waypoint)
    
    def check_threshold(self, odom):
        '''Checks the current distance from the next waypoint.  
           If it is within the threshold, update the next waypoint.
           If there is no next waypoint, then retain the current waypoint.
           When a new waypoint is added, if this is re-run, it will update to
           the new waypoint. Intended to be run as a callback function.
        '''
        
        # Get current location from odometry data
        cur_loc = (odom.pose.pose.position.x,
                   odom.pose.pose.position.y)
        
        # Fetch next waypoint from path tuple
        next_wp = self.path[self.next_waypoint]
        
        # Calculate distance between bot and waypoint
        dist = self._get_distance_to_waypoint(cur_loc, next_wp)
        
        # Test distance vs threshold distance
        if dist > self.threshold:
            # Update id of next waypoint
            self.next_waypoint = self.next_waypoint + 1
            
            # Create LineSegment msg
            line_segment = LineSegment()
            line_segment.startpoint.x = self.path[self.next_waypoint-1][0]
            line_segment.startpoint.y = self.path[self.next_waypoint-1][1]
            line_segment.endpoint.x   = self.path[self.next_waypoint][0]
            line_segment.endpoint.y   = self.path[self.next_waypoint][1]
            
            # Push ROS message with next line segment endpoints
            self._path_pub.publish(line_segment)



if __name__ == '__main__':
    try:
        # Create path generator
        pg = PathGenerator()

        # Spin until program exits
        rospy.spin()
    except rospy.ROSInterruptException:
        pass