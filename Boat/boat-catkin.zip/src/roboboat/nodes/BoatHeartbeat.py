#!/usr/bin/env python

import rospy, json, time, socket, httplib
from std_msgs.msg import String
from nmea_msgs.msg import Sentence as NMEASentence




class BoatHeartbeat():
    '''Provides the competition required heartbeat.'''
    host = 'localhost'
    port = 80
    rate = 1 # 1 Hz per competition rules
    challenge = 'test'
    position={'datum':     'WGS84',
              'latitude':  0.00,
              'longitude': 0.00}


    def __init__(self):
        self.pub = rospy.Publisher('heartbeat', String, queue_size=5)
        rospy.init_node('heartbeat', anonymous=False)
        rate = rospy.Rate(self.rate)
        
        self.host = rospy.get_param('~host')
        self.port = rospy.get_param('~port')

        rospy.loginfo('Starting heartbeat service.')
       
        hb_timer = rospy.Timer(rospy.Duration(1.0), self.sendHeartbeat)
        
        loc_sub = rospy.Subscriber("gps_nmea", NMEASentence, self.updateLocation)


    def updateLocation(self, sentence):
        '''Takes NMEA data, parses it, and updates object variables'''
        print "gps sentence get"


    def updateChallenge(self, data):
        '''Takes new challenge notification and updates variable'''
        print "updating challenge"


    def sendHeartbeat(self, event):
        '''Initiates connection and sends heartbeat'''
        timestamp = time.strftime('%Y%m%d%H%M%S', time.gmtime())
        # Encode data to JSON
        hb_json = json.dumps({'timestamp': timestamp, 'challenge': self.challenge, 'position': self.position})
        json_bytes = hb_json.encode('utf-8')

        # POST data to server
        headers = {'Content-Type': 'application/json', 'Content-Length': len(json_bytes)}
        try:
            h = httplib.HTTPConnection(self.host, self.port, timeout=2)
            h.request('POST', '/', json_bytes, headers)
            print h.getresponse().read()
        except socket.timeout:
            rospy.logerr('HTTP connection to %s timed out.', self.host)
        except socket.error:
            rospy.logerr('Unable to connect to %s.', self.host)

        log_str = 'Heartbeat Sent [{0}]: {1}'.format(rospy.get_time(), hb_json)
        self.pub.publish(log_str)




if __name__ == '__main__':
    try:
        hbSrv = BoatHeartbeat()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

