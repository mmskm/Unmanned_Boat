#!/usr/bin/env python

import asynchat

class MessageHandler(asynchat.async_chat):
    
    def __init__(self,sock, ):
        self.received_data = []
        asynchat.async_chat.__init__(self, sock)
        # Start looking for the ECHO command
        #self.process_data = self._process_command
        self.set_terminator('\n')
        
    def collect_incoming_data(self, data):
        """Read an incoming message from the client and put it into our outgoing queue."""
        self.received_data.append(data)

    def found_terminator(self):
        """The end of a command or message has been seen."""
        received_message = ''.join(self.received_data)
        print received_message
        self.received_data = []
