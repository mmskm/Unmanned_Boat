#!/bin/bash

rosrun camera_calibration cameracalibrator.py --no-service-check --approximate=0.01 --size 8x6 --square 0.100 right:=/stereo/right/image_raw left:=/stereo/left/image_raw right_camera:=/stereo/right left_camera:=/stereo/left
